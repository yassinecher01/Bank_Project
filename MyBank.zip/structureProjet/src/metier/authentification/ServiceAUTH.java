package metier.authentification;

import java.util.ArrayList;

import dao.daoFiles.ClientDao;
import dao.daoFiles.CompteDao;
import metier.InteractiveConsole;
import metier.admin.IServiceIHMAdmin;
import metier.admin.serviceIHMAdmin;
import metier.clients.ServiceIHMC;
import metier.clients.choisirCompte;
import presentation.modele.*;

public class ServiceAUTH implements IAuth,InteractiveConsole {
	ServiceIHMC serviceClient=new ServiceIHMC();
	serviceIHMAdmin serviceAdmin= new serviceIHMAdmin();
	choisirCompte compte = new choisirCompte();
	
	 
	

	@Override
	public void seConnecter(Banque banque,String username, String password, String role) {
		
		if(role.equals("oui") && username.equals("Admin") && password.equals("1234")) {
			serviceAdmin.menuGlobal(banque);
		}else if(role.equals("non")){
			
			
			for (Client client : banque.getClientsDeBanque()) {
				if(client.getPrenom().equals(username) && client.getMotDePasse().equals(password)) {
					CompteDao dao = new CompteDao();
					client.setComptesClient(dao.findAll());
					System.out.println("====================================================");
					System.out.println("-------------- bienvenue cher client ---------------");
					System.out.println("====> session ouverte pour "+client.getNom());
					Compte cmpt=compte.choisirCompt(client);
					serviceClient.menuGlobal(banque,cmpt);
				}
				else {
					System.out.println("noooo");
				}
				System.out.println(client.getNom()+" "+client.getMotDePasse());
			}
//			for(int i=0;i<banque.getClientsDeBanque().size();i++) {
//				if( username.equals(banque.getClientInBanqueWithIndex(i).getNom()) && password.equals(banque.getClientInBanqueWithIndex(i).getMotDePasse())){
//					
//					System.out.println("====================================================");
//					System.out.println("-------------- bienvenue cher client ---------------");
//					System.out.println("====> session ouverte pour "+banque.getClientInBanqueWithIndex(i).getNom());
//					Compte cmpt=compte.choisirCompt(banque.getClientInBanqueWithIndex(i));
//					serviceClient.menuGlobal(banque,cmpt);
//				}
//			}
			
		}else{
			System.out.println("====================================================");
			System.out.println("==> champs saisie incorrecte                       =");
			ServiceIHM ihm = new ServiceIHM();
			ihm.menuGlobal(banque);
		}
		
	}

	@Override
	public void SeDéconnecter() {
		// TODO Auto-generated method stub
		
	}

	

}
