package metier.authentification;

import presentation.modele.*;

public abstract interface IServiceIHM {

    void  menuGlobal(Banque banque,Compte compte);
    void  menuGlobal(Banque banque);
}
