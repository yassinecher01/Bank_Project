package metier.authentification;

import metier.InteractiveConsole;
import presentation.modele.*;

public class ServiceIHM implements IServiceIHM,InteractiveConsole{

	
	@Override
	public void menuGlobal(Banque banque,Compte compte) {
		
		
	}

	@Override
	public void menuGlobal(Banque banque) {
		String username, login, role;
		System.out.println("****************************************************");
		System.out.println("|*************** FORMULIARE DE LOGIN **************|");
		System.out.println("****************************************************");
		System.out.println("|Nom de l'utilisateur      : ");
		username=clavier.next();
		System.out.println("|Mot de passe              : ");
		login=clavier.next();
		System.out.println("|Administrateur (oui/non)? :");
		role=clavier.next();
		ServiceAUTH authentification = new ServiceAUTH();
		authentification.seConnecter(banque,username, login, role);
	}
	

}
