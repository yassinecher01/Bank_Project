package metier.authentification;

import presentation.modele.Banque;

public interface IAuth {
    void seConnecter(Banque banque, String username, String password, String role);
    void SeDéconnecter();
}
