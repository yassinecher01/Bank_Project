package metier.admin;

import java.util.Comparator;

import presentation.modele.Compte;

public class DateCompteComparator implements Comparator<Compte>{
	@Override
	public int compare(Compte c1, Compte c2) {
		 int dateCompare = c1.getDateCreation().compareTo(
                c2.getDateCreation());
		 return dateCompare;
	}
}
