package metier.admin;

import java.util.Comparator;

import presentation.modele.Client;
import presentation.modele.Compte;

public class SoldeCompteComparator implements Comparator<Compte>{
	@Override
	public int compare(Compte c1, Compte c2) {
		 int SoldeCompare = c1.getSolde().compareTo(
                c2.getSolde());
		 return SoldeCompare;
	}
}
