package metier.admin;

import java.util.Comparator;

import presentation.modele.*;

public class SoldeComparator implements Comparator<Client>{
	@Override
	public int compare(Client c1, Client c2) {Double s1=(double) 0,s2=(double) 0;
		for(Compte compte: c1.getComptesClient()) {
			s1+=compte.getSolde();
		}
		for(Compte compte: c2.getComptesClient()) {
			s2+=compte.getSolde();
		}
		 int soldeCompare = s1.compareTo(s2);
		 return soldeCompare;
	}
}
