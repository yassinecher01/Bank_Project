package metier.admin;

import metier.authentification.IServiceIHM;
import presentation.modele.Banque;
import presentation.modele.Compte;

public interface IServiceIHMAdmin extends IServiceIHM {

    int menuModification	(Banque banque, Compte compte);
    int menuRecherche		(Banque banque, Compte compte);
    int menuInformations	(Banque banque, Compte compte);
    int menuAjout			(Banque banque, Compte compte);
    int menuSuppression		(Banque banque, Compte compte);
    int tableauDeBord		(Banque banque);
    int menuTrie			(Banque banque, Compte compte);
    int menuComptabilité	();

}
