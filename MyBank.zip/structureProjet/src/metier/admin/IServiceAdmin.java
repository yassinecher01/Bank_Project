package metier.admin;

import presentation.modele.Banque;
import presentation.modele.Client;
import presentation.modele.Compte;
import presentation.modele.Sexe;
import presentation.modele.TableauDeBord;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

public interface IServiceAdmin {

    boolean          nouveauClient(Banque banque ,String login,String password,String nom,String prenom,String mail,String cin,String tel, Sexe sexe);
    boolean          nouveauCompteClientExistant(Banque banque,Client clien, Double solde);
    boolean			supprimerCompteClientExistant(Banque banque, String numeroCompte);

    Client          chercherClientParId(Banque banque, Long id);
    List<Client>    chercherClientParNom(Banque banque,String nom);
    List<Client>    chercherClientParPrénom(Banque banque, String prenom);
    Client          chercherClientParCin(Banque banque, String cin);
    Client          chercherClientParEmail(Banque banque, String email);

    Compte          chercherCompteParNumeroDeCompte(Banque banque, String numeroDeCompte);
    List<Compte>    chercherCompteParSolde(Banque banque, double solde);
    List<Compte>    chercherCompteParDateCreation(Banque banque, Date date);
    List<Compte>    chercherCompteParPropriétaire(Banque banque, Client propriétaire);

    Client          modifierClient(Client client,String filtre);
    boolean         supprimerClient(Banque banque, Long id);

    TableauDeBord   calculerEtAfficherStatistiques(Banque banque);

    List<Client>    trierClientParNom(Banque banque);
    List<Client>    trierClientParCin(Banque banque);
    List<Client>    trierClientParEmail(Banque banque);
    List<Client>    trierClientParSoldeCompte(Banque banque);
    List<Compte>    trierComptesParSolde(Client client);
    List<Compte>    trierComptesParDateDeCreation(Client client);
    List<Compte>    trierComptesParNomPropriétaire(Client client);

}
