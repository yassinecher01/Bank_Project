package metier.admin;

import java.time.LocalDateTime;
import java.util.*;

import dao.daoFiles.ClientDao;
import dao.daoFiles.CompteDao;
import metier.InteractiveConsole;
import presentation.modele.Banque;
import presentation.modele.Client;
import presentation.modele.Compte;
import presentation.modele.Sexe;
import presentation.modele.TableauDeBord;

public class ServiceAdmin implements IServiceAdmin,InteractiveConsole {
	TableauDeBord tableau;
	ClientDao dao=new ClientDao();
	CompteDao daoCompte= new CompteDao();
	
	@Override
	public boolean nouveauClient(Banque banque, String login, String password, String nom, String prenom, String mail,
			String cin, String tel, Sexe sexe) {
		Client client=new Client(login,password,nom,prenom,mail,cin,tel,sexe);
		banque.addClientDeBanque(client);
		dao.save(client);
		return true;
	}

	//a tester
	@Override
	public boolean nouveauCompteClientExistant(Banque banque , Client client, Double solde) {
		Compte compte=new Compte(solde,client);
		client.addCompteDeClient(compte);
		daoCompte.save(compte);
		return true;
	}

	@Override
	public Client chercherClientParId(Banque banque ,Long id) {
		for(Client client: banque.getClientsDeBanque()) {
			if(client.getId().equals(id)) return client;
		}
		System.out.println("client introuvable");
		return null;
	}

	@Override
	public List<Client> chercherClientParNom(Banque banque, String nom) {
		ArrayList <Client> clientnom = new ArrayList <Client>();
		for(Client client: banque.getClientsDeBanque()) {
			if(client.getNom().equals(nom)) clientnom.add(client);
		}
		if(clientnom.isEmpty()) {
			System.out.println("client introuvable");
			return null;
		}
		return clientnom;
		
	}

	@Override
	public List<Client> chercherClientParPrénom(Banque banque, String prenom) {
		ArrayList <Client> clientprenom = new ArrayList <Client>();
		for(Client client: banque.getClientsDeBanque()) {
			if(client.getPrenom().equals(prenom)) clientprenom.add(client);
		}
		if(clientprenom.isEmpty()) {
			System.out.println("client introuvable");
			return null;
		}
		return clientprenom;
	}

	@Override
	public Client chercherClientParCin(Banque banque, String cin) {
		for(Client client: banque.getClientsDeBanque()) {
			if(client.getCin().equals(cin)) return client;
		}
		System.out.println("client introuvable");
		return null;
		
	}

	@Override
	public Client chercherClientParEmail(Banque banque, String email) {
		for(Client client: banque.getClientsDeBanque()) {
			if(client.getEmail().equals(email)) return client;
		}
		System.out.println("client introuvable");
		return null;
	}

	@Override
	public Compte chercherCompteParNumeroDeCompte(Banque banque, String numeroDeCompte) {
		for(Client client : banque.getClientsDeBanque()) {
			for(Compte compte : client.getComptesClient() ) {
				if(compte.getNumeroCompte().equals(numeroDeCompte)) return compte;
			}
		}
		
		System.out.println("compte introuvable");
		return null;
	}

	@Override
	public List<Compte> chercherCompteParSolde(Banque banque, double solde) {
		ArrayList <Compte> comptesolde = new ArrayList <Compte>();
		for (Client client : banque.getClientsDeBanque()) {
			for(Compte compte : client.getComptesClient() ) {
				if(compte.getSolde().equals(solde)) comptesolde.add(compte);
			}
		}
		
		if(comptesolde.isEmpty()) {
			System.out.println("==> compte introuvable");
			return null;
		}
		System.out.println("==> compte introuvable");
		return comptesolde;
	}
	
	@Override
	public List<Compte> chercherCompteParDateCreation(Banque banque, Date date) {
		ArrayList <Compte> comptedate = new ArrayList <Compte>();
		System.out.println("entrer l'id du client");
		Long idclient=Long.parseLong(clavier.nextLine());
		Client client=chercherClientParId(banque, idclient);
		for(Compte compte : client.getComptesClient() ) {
			if(compte.getDateCreation().equals(date)) comptedate.add(compte);
		}
		if(comptedate.isEmpty()) {
			System.out.println("compte introuvable");
			return null;
		}
		System.out.println("compte introuvable");
		return comptedate;
	}

	@Override
	public List<Compte> chercherCompteParPropriétaire(Banque banque, Client propriétaire) {
		ArrayList <Compte> compteproprietaire = new ArrayList <Compte>();
		System.out.println("entrer l'id du client");
		Long idclient=Long.parseLong(clavier.nextLine());
		Client client=chercherClientParId(banque, idclient);
		for(Compte compte : client.getComptesClient() ) {
			if(compte.getPropriétaire().equals(propriétaire)) compteproprietaire.add(compte);
		}
		if(compteproprietaire.isEmpty()) {
			System.out.println("compte introuvable");
			return null;
		}
		System.out.println("compte introuvable");
		return compteproprietaire;
	}

	@Override
	public Client modifierClient(Client client, String filtre) {
		switch (filtre) {
		case "nom": {
			System.out.println("==> entrer le nouveau nom: ");
			client.setNom(clavier.nextLine());
			dao.update(client);
			break;
		}
		
case "prenom": {
	System.out.println("==> entrer le nouveau prenom: ");
			client.setPrenom(clavier.nextLine());
			dao.update(client);
			break;
		}
case "tel": {
	System.out.println("==> entrer le nouveau n° tel: ");
	client.setTel(clavier.nextLine());
	dao.update(client);
	break;
}
case "email": {
	System.out.println("==> entrer le nouveau email: ");
	client.setEmail(clavier.nextLine());
	dao.update(client);
	break;
}
case "sexe": {
	System.out.println("==> entrer le nouveau sexe:");
	String s=clavier.nextLine();
	Sexe sexe = null;
	if(s.equals("Homme") || s.equals("H")) sexe=Sexe.HOMME;
	if(s.equals("Femme") || s.equals("F")) sexe=Sexe.FEMME;
	client.setSexe(sexe);
	dao.update(client);
	break;
}
case "cin": {
	System.out.println("==> entrer le nouveau n° cin:");
	client.setCin(clavier.nextLine());
	dao.update(client);
	break;
}
		default:
			throw new IllegalArgumentException("Unexpected value: " + filtre);
		}
		return null;
	}

	@Override
	public boolean supprimerClient(Banque banque, Long id) {
		for(Client client : banque.getClientsDeBanque()) {
			if(client.getId().equals(chercherClientParId(banque, id).getId())) {
				int i=banque.getClientsDeBanque().indexOf(client);
				banque.setClientInBanque(i, null);
				dao.delete(client);
			}
		}
		;
		return false;
	}

	@Override
	public TableauDeBord calculerEtAfficherStatistiques(Banque banque) {
		double maxsolde=0,minsolde=0;
		Long h=(long) 0,f=(long) 0,nbclient=(long) 0,nbcompte=(long) 0;
		String nom=null;
		
		for(Client client : banque.getClientsDeBanque()) {
			if (client.getSexe().equals("Homme")) {
				h++;
			}
			if (client.getSexe().equals("Femme")) {
				f++;
			}
			for(Compte compte : client.getComptesClient()) {
				nbcompte++;
				if(compte.getSolde()>maxsolde) {
					maxsolde=compte.getSolde();
					nom=compte.getPropriétaire().getNom()+" "+compte.getPropriétaire().getPrenom();
				}
				if(compte.getSolde()<maxsolde) {
					minsolde=compte.getSolde();
				}
			}
			
		}
		nbclient=(long) banque.getClientsDeBanque().size();
		TableauDeBord tableau = new TableauDeBord(nbcompte,nbclient,maxsolde,minsolde,nom,f,h);
		return tableau;
	}

	@Override
	public List<Client> trierClientParNom(Banque banque) {
		
		Collections.sort(banque.getClientsDeBanque(),
				(c1,c2) -> c1.getNom().compareTo(c2.getNom()));
		
		return banque.getClientsDeBanque();
	}

	@Override
	public List<Client> trierClientParCin(Banque banque) {
		Collections.sort(banque.getClientsDeBanque(),
				(c1,c2) -> c1.getCin().compareTo(c2.getCin()));
		
		return banque.getClientsDeBanque();
	}

	@Override
	public List<Client> trierClientParEmail(Banque banque) {
		Collections.sort(banque.getClientsDeBanque(),
				(c1,c2) -> c1.getEmail().compareTo(c2.getEmail()));
		
		return banque.getClientsDeBanque();
	}

	@Override
	public List<Client> trierClientParSoldeCompte(Banque banque) {
		Collections.sort(banque.getClientsDeBanque(),
				(c1,c2) -> c1.getSoldeTotal().compareTo(c2.getSoldeTotal()));
		
		return banque.getClientsDeBanque();
	}
	

	@Override
	public List<Compte> trierComptesParSolde(Client client) {
		
		Collections.sort(client.getComptesClient(),
				(c1,c2) -> c1.getSolde().compareTo(c2.getSolde()));
		
		return client.getComptesClient();
	}

	@Override
	public List<Compte> trierComptesParDateDeCreation(Client client) {
		
		Collections.sort(client.getComptesClient(),
				(c1,c2) -> c1.getDateCreation().compareTo(c2.getDateCreation()));
		
		return client.getComptesClient();
	}
	@Override
	public List<Compte> trierComptesParNomPropriétaire(Client client) {
		
		Collections.sort(client.getComptesClient(),
				(c1,c2) -> c1.getPropriétaire().compareTo(c2.getPropriétaire()));
		
		return client.getComptesClient();
	}
	
	public int tableauDeBord(Banque banque) {
		 Long    nombreTotaleClient = (long) banque.getClientsDeBanque().size();
	     Long    nombreTotaleCompte = (long) 0 ;
	     Double  maxSolde=(double) 0;
	     Double  minSolde=(double) 0;
	     String  nomClientLePlusRiche= null;
	     Long    totalClientsFemme=(long) 0, totaleClientsHomme=(long) 0;
	     
	      
	     
	     
	     for (Client client : banque.getClientsDeBanque()) {
	    	 if(client.getSexe().equals("Homme")) {
	    		 totaleClientsHomme++;
	    	 }else {
	    		 totalClientsFemme++;
	    	 }
	    	 for (Compte compte : client.getComptesClient()) {
	    		 nombreTotaleCompte++;
			}
			
		}
	     ArrayList<Double> soldes = new ArrayList<Double>();
	     for (Client client : banque.getClientsDeBanque()) {
	    	 for (Compte compte : client.getComptesClient()) {
	    		 soldes.add(compte.getSolde());
			}
			
		}
	     Collections.sort(soldes);
	     minSolde=soldes.get(0);
	     maxSolde=soldes.get(soldes.size()-1);
	     
	     
	     
	     ArrayList<Double> solde = new ArrayList<>();
	     
	     for (Client client : banque.getClientsDeBanque()) {
	    	 for (Compte compte : client.getComptesClient()) {
	    		 solde.add(compte.getSolde());
	    		 
			}
			
		}
	     Collections.sort(solde);
	     for (Client client : banque.getClientsDeBanque()) {
	    	 if(client.getSoldeTotal().equals(solde.get(solde.size()-1))) nomClientLePlusRiche=client.getNom();
	     }
	     
	      tableau = new TableauDeBord(nombreTotaleClient, nombreTotaleCompte, maxSolde, minSolde, nomClientLePlusRiche, totalClientsFemme, totaleClientsHomme);
	     
		return 0;
	}
	
//	@Override
//	public List<Compte> trierComptesParNomPropriétaire(Banque banque) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	@Override
	public boolean supprimerCompteClientExistant(Banque banque, String numeroCompte) {
		for (Client client : banque.getClientsDeBanque()) {
			for(Compte compte : client.getComptesClient()) {
				if(compte.getNumeroCompte().equals(numeroCompte)) {
					
					int i= client.getComptesClient().indexOf(compte);
					client.setCompteDeClient(i, null);	
					daoCompte.delete(compte);  
					 return true;
				}
			}
		}
		return false;
	}

	

	

	

	

}
