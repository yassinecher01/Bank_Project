package metier.admin;

import java.util.Comparator;

import presentation.modele.Client;

public class EmailComparator implements Comparator< Client> {
	@Override
	public int compare(Client c1, Client c2) {
		 int EmailCompare = c1.getEmail().compareTo(
                c2.getEmail());
		 return EmailCompare;
	}

}
