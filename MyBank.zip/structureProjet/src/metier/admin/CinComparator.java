package metier.admin;
import java.util.*;

import presentation.modele.Client;
public class CinComparator implements Comparator< Client>{
	@Override
	public int compare(Client c1, Client c2) {
		 int CinCompare = c1.getCin().compareTo(
                c2.getCin());
		 return CinCompare;
	}
}
