package metier.admin;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import dao.daoFiles.ClientDao;
import metier.InteractiveConsole;
import metier.authentification.ServiceIHM;
import metier.clients.choisirCompte;
import presentation.modele.*;

public  class serviceIHMAdmin implements IServiceIHMAdmin{
	
	Scanner clavier = new Scanner(System.in);
	
	
	ServiceAdmin serviceA = new ServiceAdmin();
	Compte compte = new Compte();
	int choix;

	
	
	@Override
	public void menuGlobal(Banque banque, Compte compte) {
		
	}
	
	
	
	
	
	public int menuCRUD(Banque banque, Compte compte) {
		
		int c;
		
		System.out.println("====================================================");
		System.out.println("=================> M E N U [CRUD] <=================");
		System.out.println("==                                                ==");
		System.out.println("= tapez 1 pour le [MENU D'AJOUT]                   =");
		System.out.println("= tapez 2 pour le [MENU DE MODIFICATION]           =");
		System.out.println("= tapez 3 pour le [MENU DE SUPRESSION]             =");
		System.out.println("= tapez 4 pour le [MENU DE RECHERCHE]              =");
		System.out.println("= tapez 5 pour retourner au menu global            =");
		System.out.println("==                                                ==");
		System.out.println("====================================================");
		System.out.println("=> entrer votre choix:");
		c=clavier.nextInt();
		
		switch (c) {
		case 1: {
			
			menuAjout(banque, compte);break;
		}
case 2: {
			
			menuModification(banque,compte);break;
		}
case 3: {
	
	menuSuppression(banque,compte);break;
}
case 4:{
	menuRecherche(banque,compte);break;
}
case 5: {
	
	menuGlobal(banque);
}
		default:
			throw new IllegalArgumentException("Unexpected value: " + c);
		}
		return 0;
	}
	
	
	
	
	

	@Override
	public int menuModification(Banque banque, Compte compte) {
		
		int c;
		System.out.println("====================================================");
		System.out.println("=============> M E N U [MODIFICATION] <=============");
		System.out.println("==                                                ==");
		System.out.println("= tapez 1 pour modifier le nom                     =");
		System.out.println("= tapez 2 pour modifier le prenom                  =");
		System.out.println("= tapez 3 pour le n° telephone                     =");
		System.out.println("= tapez 4 pour l'email                             =");
		System.out.println("= tapez 5 pour le sexe                             =");
		System.out.println("= tapez 6 pour n° cin                              =");
		System.out.println("= tapez 7 pour retourner au menu global            =");
		System.out.println("==                                                ==");
		System.out.println("====================================================");
		System.out.println("=> entrer votre choix:");
		c=clavier.nextInt();
		Client client=compte.getPropriétaire();
		switch (c) {
		case 1: {
			
			serviceA.modifierClient(client, "nom");break;
		}
case 2: {
			
	serviceA.modifierClient(client, "prenom");break;
		}
case 3: {
	
	serviceA.modifierClient(client, "tel");break;
}
case 4: {
	
	serviceA.modifierClient(client, "email");break;
}
case 5: {
	
	serviceA.modifierClient(client, "sexe");break;
}
case 6: {
	
	serviceA.modifierClient(client, "cin");break;
}
case 7: {
	
	menuGlobal(banque);
}
		default:
			throw new IllegalArgumentException("Unexpected value: " + c);
		}
		return 0;
	}
	
	
	
	

	@Override
	public int menuRecherche(Banque banque, Compte compte) {
		int c;
		System.out.println("====================================================");
		System.out.println("==============> M E N U [RECHERCHE] <===============");
		System.out.println("==                                                ==");
		System.out.println("-                    client                        -");
		System.out.println("                                                    ");
		System.out.println("= tapez 1 pour chercher client par id              =");
		System.out.println("= tapez 2 pour chercher client par nom             =");
		System.out.println("= tapez 3 pour chercher client par prenom          =");
		System.out.println("= tapez 4 pour chercher client par cin             =");
		System.out.println("= tapez 5 pour chercher client par email           =");
		System.out.println("                                                    ");
		System.out.println("-                    compte                        -");
		System.out.println("                                                    ");
		System.out.println("= tapez 6 pour chercher compte par n° de compte    =");
		System.out.println("= tapez 7 pour chercher compte par solde           =");
		System.out.println("= tapez 8 pour chercher compte par date de creation=");
		System.out.println("= tapez 9 pour chercher compte par proprietaire    =");
		System.out.println("= tapez 10 pour retourner au menu global           =");
		System.out.println("==                                                ==");
		System.out.println("====================================================");
		System.out.println("=> entrer votre choix:");
		c=clavier.nextInt();
		
		switch (c) {
case 1: {
	clavier.nextLine();
			System.out.println("====================================================");
			System.out.println("= entrer l'id du client cible                      =");
			Long id = clavier.nextLong();
			System.out.println( serviceA.chercherClientParId(banque,id ).toString());
			menuRecherche(banque, compte);
			break;
		}
case 2: {
	clavier.nextLine();
	System.out.println("====================================================");
	System.out.println("= entrer le nom du client cible                    =");
	String nom=clavier.nextLine();
	System.out.println( serviceA.chercherClientParNom(banque, nom).toString());
	menuRecherche(banque, compte);
	break;
}
case 3: {
	clavier.nextLine();
	System.out.println("====================================================");
	System.out.println("= entrer le prenom du client cible                 =");
	String prenom =clavier.nextLine();
	System.out.println( serviceA.chercherClientParPrénom(banque, prenom).toString());
	menuRecherche(banque, compte);
	break;
}
case 4: {
	clavier.nextLine();
	System.out.println("====================================================");
	System.out.println("= entrer le n° cin du client cible                 =");
	String cin = clavier.nextLine();
	System.out.println( serviceA.chercherClientParCin(banque, cin).toString());
	menuRecherche(banque, compte);
	break;
}
case 5: {
	
	clavier.nextLine();
	System.out.println("====================================================");
	System.out.println("= entrer l'email du client cible                   =");
	String email=clavier.nextLine();
	System.out.println( serviceA.chercherClientParEmail(banque, email).toString());
	menuRecherche(banque, compte);
	break;
}
case 6: {
	clavier.nextLine();
	System.out.println("====================================================");
	System.out.println("= entrer le numero de compte cible                 =");
	String num = clavier.nextLine();
	System.out.println( serviceA.chercherCompteParNumeroDeCompte(banque, num).toString());
	menuRecherche(banque, compte);
	break;
}
case 7: {
	clavier.nextLine();
	System.out.println("====================================================");
	System.out.println("= entrer le solde de compte cible                  =");
	int solde = clavier.nextInt();
	System.out.println( serviceA.chercherCompteParSolde(banque, solde).toString());
	menuRecherche(banque, compte);
	break;
}
case 8: {
	clavier.nextLine();
	System.out.println("====================================================");
	System.out.println("= entrer la date de creation du compte cible JJ/MM/YYYY =");
	menuRecherche(banque, compte);
	
	String date=clavier.next();
	clavier.useDelimiter("/");
	DateFormat formatter = new SimpleDateFormat(" dd MM yyyy");
	Date d;
	try {
		d = formatter.parse(date);
		System.out.println( serviceA.chercherCompteParDateCreation(banque, d).toString());
		menuRecherche(banque, compte);
	break;
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
case 9: {
	clavier.nextLine();
	System.out.println("====================================================");
	System.out.println("= entrer le nom du proprietaire du compte cible    =");
	String nom = clavier.nextLine();
	System.out.println("= entrer le prenom du proprietaire du compte cible =");
	String prenom = clavier.nextLine();
	Client cli = new Client(nom, prenom);
	System.out.println( serviceA.chercherCompteParPropriétaire(banque, cli));
	menuRecherche(banque, compte);
	break;
}
case 10: {
	
	menuGlobal(banque, compte);break;
}
		default:
			throw new IllegalArgumentException("Unexpected value: " + c);
		}
		return 0;
	}

	
	
	@Override
	public int menuInformations(Banque banque, Compte compte) {
		TableauDeBord tableau = serviceA.calculerEtAfficherStatistiques(banque);
		int c;
		System.out.println("====================================================");
		System.out.println("=============> M E N U [INFORMATION] <==============");
		System.out.println("==                                                ==");
		System.out.println("-                    client                        -");
		System.out.println("                                                    ");
		System.out.println("= tapez 1 pour afficher le nombre total des clients ");
		System.out.println("= tapez 2 pour afficher le client aiyant le solde MAX =");
		System.out.println("= tapez 3 pour afficher le client aiyant le solde MIN =");
		System.out.println("= tapez 4 pour afficher le nombre total des clients F =");
		System.out.println("= tapez 5 pour afficher le nomre total des clients H =");
		System.out.println("                                                    ");
		System.out.println("-                    compte                        -");
		System.out.println("                                                    ");
		System.out.println("= tapez 6 pour afficher le nombre total des comptes =");
		System.out.println("                                                    ");
		System.out.println("= tapez 7 pour retourner au menu global            =");
		System.out.println("==                                                ==");
		System.out.println("====================================================");
		System.out.println("=> entrer votre choix:");
		c=clavier.nextInt();
		
		switch (c) {
		case 1: {
			
			
			System.out.println(tableau.getNombreTotaleClient()); menuInformations(banque, compte) ;break;
		}
case 2: {
			
	System.out.println(tableau.getNomClientLePlusRiche());menuInformations(banque, compte) ;break;
		}
case 3: {
	for(Client client : banque.getClientsDeBanque()) {
		if(client.getSoldeTotal().equals(tableau.getMinSolde())) 
			System.out.println(client.getNomComplet()); 
		
	}
	menuInformations(banque, compte);
	break;
}
case 4: {
	
	System.out.println(tableau.getTotalClientsFemme());
	menuInformations(banque, compte);break;
}
case 5: {
	
	System.out.println(tableau.getTotaleClientsHomme());
	menuInformations(banque, compte);break;
}
case 6: {
	
	System.out.println(tableau.getNombreTotaleCompte());
	menuInformations(banque, compte);break;
}
case 7: {
	
	menuGlobal(banque);
}
		default:
			throw new IllegalArgumentException("Unexpected value: " + c);
		}
		return 0;
	}

	@Override
	public int menuAjout(Banque banque, Compte compte) {
		
		
		System.out.println("====================================================");
		System.out.println("================> M E N U [AJOUT] <=================");
		System.out.println("==                                                ==");
		System.out.println("-                    client                        -");
		System.out.println("                                                    ");
		System.out.println("= tapez 1 pour ajouter un client                   =");
		System.out.println("                                                    ");
		System.out.println("-                    compte                        -");
		System.out.println("                                                    ");
		System.out.println("= tapez 2 pour ajouter un compte à un client       =");
		System.out.println("                                                    ");
		System.out.println("= tapez 3 pour retourner au menu global            =");
		System.out.println("==                                                ==");
		System.out.println("====================================================");
		System.out.println("=> entrer votre choix:");
		int choix = clavier.nextInt();
		clavier.nextLine();
		
		switch (choix) {
		case 1: {
			String login,password,nom,prenom,mail,cin,tel,s;
			Sexe sexe = null;
			System.out.println("====================================================");
			System.out.println("==> enter le nom:");
			nom=clavier.nextLine();
			System.out.println("==> enter le prenom:");
			prenom=clavier.nextLine();
			System.out.println("==> enter le login:");
			login=clavier.nextLine();
			System.out.println("==> enter le password:");
			password=clavier.nextLine();
			System.out.println("==> enter le mail:");
			mail=clavier.nextLine();
			System.out.println("==> enter le cin:");
			cin=clavier.nextLine();
			System.out.println("==> enter le tel:");
			tel=clavier.nextLine();
			System.out.println("==> enter le sexe:");
			s=clavier.nextLine();
			if(s.equals("Homme") || s.equals("H")) sexe=Sexe.HOMME ;
			if(s.equals("Femme") || s.equals("F")) sexe=Sexe.FEMME;
			
			if(serviceA.nouveauClient(banque, login, password, nom, prenom, mail, cin, tel, sexe)) menuAjout(banque, compte);
		}
case 2: {
			System.out.println("====================================================");
			System.out.println("==> enter le solde:");
			Double solde=clavier.nextDouble();
			clavier.nextLine();
			System.out.println("==> entrer le cin:");
			String cin=clavier.nextLine();
			Client client=serviceA.chercherClientParCin(banque, cin);
			if(client!=null) {
				if(serviceA.nouveauCompteClientExistant(banque, client, solde))menuAjout(banque, compte);
				else{
					System.out.println("==> operation iterrompue");
					menuAjout(banque, compte);
				}
			}else {
				System.out.println("==> operation iterrompue");
				menuAjout(banque, compte);
			}
			
			break;
		}
case 3: {
	
	menuGlobal(banque);break;
}
		default:
			throw new IllegalArgumentException("Unexpected value: " + choix);
		}
		return 0;
	}

	@Override
	public int menuSuppression(Banque banque, Compte compte) {
		
		System.out.println("====================================================");
		System.out.println("=============> M E N U [SUPPRESSION] <==============");
		System.out.println("==                                                ==");
		System.out.println("-                    client                        -");
		System.out.println("                                                    ");
		System.out.println("= tapez 1 pour supprimer un client                 =");
		System.out.println("                                                    ");
		System.out.println("-                    compte                        -");
		System.out.println("                                                    ");
		System.out.println("= tapez 2 pour supprimer un compte d'un client     =");
		System.out.println("                                                    ");
		System.out.println("= tapez 3 pour retourner au menu global            =");
		System.out.println("==                                                ==");
		System.out.println("====================================================");
		System.out.println("=> entrer votre choix:");
		int choix=clavier.nextInt();
		
		switch (choix) {
		case 1: {
			
			System.out.println("====================================================");
			System.out.println("==> enter l'id du client que vous voulez supprimer =");
			Long id=clavier.nextLong();
			System.out.println("==> etes-vous sure?? (O/N)?");
			String s=clavier.nextLine();
			if(s.equals('O')) {
				if(serviceA.supprimerClient(banque, id)) menuSuppression(banque, compte);
				
			}else {
				System.out.println("==> operation interrompue");
				menuSuppression(banque, compte);
			}
			break;
		}
case 2: {
	System.out.println("====================================================");
	System.out.println("==> enter l'id du compte que vous voulez supprimer =");
	String id=clavier.nextLine();
	System.out.println("==> etes-vous sure?? (O/N)?");
	String s=clavier.nextLine();
	if(s.equals('O')) {
		if(serviceA.supprimerCompteClientExistant(banque, id)) menuSuppression(banque, compte);
	}else {
		System.out.println("==> operation interrompue");
		menuSuppression(banque, compte);
	}
			break;
		}
case 3: {
	
	menuGlobal(banque, compte);
}
		default:
			throw new IllegalArgumentException("Unexpected value: " + choix);
		}
		return 0;
	}

	@Override
	public int tableauDeBord(Banque banque) {
		serviceA.tableauDeBord(banque);
		return 0;
	}

	@Override
	public int menuTrie(Banque banque, Compte compte) {
		
		System.out.println("====================================================");
		System.out.println("================> M E N U [TRIE] <==================");
		System.out.println("==                                                ==");
		System.out.println("-                    client                        -");
		System.out.println("                                                    ");
		System.out.println("= tapez 1 pour trier les client par leurs noms     =");
		System.out.println("= tapez 2 pour trier les client par leurs cin      =");
		System.out.println("= tapez 3 pour trier les client par leurs email    =");
		System.out.println("= tapez 4 pour trier les client par leurs solde    =");
		System.out.println("                                                    ");
		System.out.println("-                    compte                        -");
		System.out.println("                                                    ");
		System.out.println("= tapez 5 pour trier compte par solde              =");
		System.out.println("= tapez 6 pour trier compte par date de creation   =");
		System.out.println("                                                    ");
		System.out.println("= tapez 7 pour retourner au menu global            =");
		System.out.println("==                                                ==");
		System.out.println("====================================================");
		System.out.println("=> entrer votre choix:");
		int choix = clavier.nextInt();
		
		switch (choix) {
		case 1: {
			
			System.out.println(serviceA.trierClientParNom(banque));menuTrie(banque, compte) ;break;
		}
case 2: {
			
	System.out.println(serviceA.trierClientParCin(banque));menuTrie(banque, compte) ;break;
		}
case 3: {
	
	System.out.println(serviceA.trierClientParEmail(banque));menuTrie(banque, compte) ;break;
}
case 4: {
	
	System.out.println(serviceA.trierClientParSoldeCompte(banque));menuTrie(banque, compte) ;break;
}
case 5: {
	System.out.println(serviceA.trierComptesParSolde(compte.getPropriétaire()));menuTrie(banque, compte) ;
	break;
}
case 6: {
	
	System.out.println(serviceA.trierComptesParDateDeCreation(compte.getPropriétaire()));menuTrie(banque, compte) ;break;
}
case 7: {
	
	menuGlobal(banque);
}
		default:
			throw new IllegalArgumentException("Unexpected value: " + choix);
		}
		return 0;
	}

	@Override
	public int menuComptabilité() {
		// TODO Auto-generated method stub
		return 0;
	}





	@Override
	public void menuGlobal(Banque banque) {
		
		
		
		System.out.println("====================================================");
		System.out.println("============> M E N U [ADMINISTRAREUR] <============");
		System.out.println("==                                                ==");
		System.out.println("= tapez 1 pour le [SERVICE CRUD]                   =");
		System.out.println("= tapez 2 pour le [SERVICE INFORMATION]            =");
		System.out.println("= tapez 3 pour le [SERVICE TRIE]                   =");
		System.out.println("= tapez 4 pour le [TABLEAU DE BORD - STATISTIQUE]  =");
		System.out.println("= tapez 5 pour se deconnecter                      =");
		System.out.println("==                                                ==");
		System.out.println("====================================================");
		System.out.println("=> entrer votre choix:");
		choix=clavier.nextInt();
		
		switch (choix) {
		case 1: {
			
			menuCRUD(banque,compte);break;
		}
case 2: {
			menuInformations(banque,compte);break;
		}
case 3: {
	
	menuTrie(banque,compte);break;
}
case 4: {
	
	menuInformations(banque,compte);break;
}
case 5: {
	
	System.out.println("====================================================");
	System.out.println("==> au revoir MR.Yassine");
	System.out.println("====================================================");
	
	ServiceIHM authentification = new ServiceIHM();
	authentification.menuGlobal(banque);
}
		default: 

		}		
	}

}
