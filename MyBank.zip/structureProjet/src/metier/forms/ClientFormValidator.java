package metier.forms;

import presentation.modele.entitesDeLaBanque.Utilisateur;

public class ClientFormValidator {




    public boolean createSession(Utilisateur newUser){

        return false;
    }
}
