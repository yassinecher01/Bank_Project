package metier.clients;

import presentation.modele.*;

public interface IServiceClient {

        boolean versement(Compte compte);
        boolean retrait  (Compte compte, Double montant);
        
        boolean virement (Banque banque,Compte compte);
        boolean modifierProfile(Compte compte,int choixModification);
        void dernièresOpérations(Compte compte);
        Double afficherSolde(Compte compte);

        void afficherTicket();

}
