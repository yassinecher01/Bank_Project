package metier.clients;

import metier.InteractiveConsole;
import presentation.modele.*;

public class choisirCompte implements InteractiveConsole {

	public Compte choisirCompt(Client user) {
		System.out.println("====================================================");
		System.out.println("================= choisir un compte ================");
		System.out.println("                          ||                        ");
		System.out.println("                         _||_                       ");
		System.out.println("                         \\//                       ");
		System.out.println("                          VV                        ");
		System.out.println("====================================================");
		for (Compte compte : user.getComptesClient()) {
			System.out.println("== taper "+user.getComptesClient().indexOf(compte)+" pour choisir le compte :"+compte.getNumeroCompte()+"\n");
		}
		int compte = clavier.nextInt();
		return user.getCompteDeClientWithIndex(compte);
	}
}
