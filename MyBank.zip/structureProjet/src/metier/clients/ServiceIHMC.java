package metier.clients;

import metier.InteractiveConsole;
import metier.authentification.ServiceIHM;
import presentation.modele.*;

public  class ServiceIHMC implements IServiceIHMClient,InteractiveConsole{
	ServiceClient serviceclient = new ServiceClient();
	choisirCompte choisircompte = new choisirCompte();
	ServiceIHM authetification = new ServiceIHM();

	@Override
	public void menuGlobal(Banque banque,Compte compte) {
			
			System.out.println("====================================================");
			System.out.println("==============> M E N U [PRINCIPALE] <==============");
			System.out.println("==                                                ==");
			System.out.println("= tapez 1 pour faire un versement                  =");
			System.out.println("= tapez 2 pour faire un retrait                    =");
			System.out.println("= tapez 3 pour faire un virement                   =");
			System.out.println("= tapez 4 pour modifier votre profile              =");
			System.out.println("= tapez 5 pour afficher les informations du compte =");
			System.out.println("= tapez 6 pour afficher le solde actuel du compte  =");
			System.out.println("= tapez 7 pour changer de compte                   =");
			System.out.println("= tapez 8 pour se deconnecter                      =");
			System.out.println("==                                                ==");
			System.out.println("====================================================");
			System.out.println("=> entrer votre choix:");
			int choix = clavier.nextInt();
			switch (choix) {
			case 1: {
				
				if(serviceclient.versement(compte))menuGlobal(banque,compte);
				else {
					System.out.println("opperation interrompue");
					menuGlobal(banque,compte);
				}break;
			}
case 2: {
				
	menuRetrait(banque, compte);break;
			}
case 3: {
	if(serviceclient.virement(banque,compte))menuGlobal(banque,compte);
	else {
		System.out.println("opperation interrompue");
		menuGlobal(banque,compte);
	}break;
}
case 4: {
	
	menuModification(banque, compte);break;
}
case 5: {
	
	menuInformations(banque,compte);break;
}
case 6: {
	
	System.out.println("====================================================");
	System.out.println("==> solde actuel: "+compte.getSolde());
	System.out.println("====================================================");
	break;
}
case 7: {
	
	choisircompte.choisirCompt(compte.getPropriétaire());break;
}
case 8: {
	
	System.out.println("====================================================");
	System.out.println("==> au revoir MR."+compte.getPropriétaire().getPrenom());
	System.out.println("====================================================");
	authetification.menuGlobal(banque);
	break;
	
}
			default:
				throw new IllegalArgumentException("Unexpected value: " + choix);
			}
			
	}

	@Override
	public void  menuModification(Banque banque, Compte compte) {
		System.out.println("====================================================");
		System.out.println("=============> M E N U [MODIFICATION] <=============");
		System.out.println("==                                                ==");
		System.out.println("= tapez 1 pour modifier votre nom et prenom        =");
		System.out.println("= tapez 2 pour modifier le MDP de votre compte     =");
		System.out.println("= tapez 3 pour modifier votre email                =");
		System.out.println("= tapez 4 pour modifier votre n° cin               =");
		System.out.println("= tapez 5 pour modifier votre n° telephone         =");
		System.out.println("= tapez 6 pour retourner au menu principale        =");
		System.out.println("==                                                ==");
		System.out.println("====================================================");
		System.out.println("=> entrer votre choix:");
		int choix=clavier.nextInt();
		
		switch (choix) {
		case 1: {
			
			if(serviceclient.modifierProfile(compte, choix)) menuModification(banque, compte);
				else {
					System.out.println("opperation interrompue");
					menuGlobal(banque,compte);
				};break;
		}
case 2: {
			
	if(serviceclient.modifierProfile(compte, choix))menuModification(banque, compte);
	else {
		System.out.println("opperation interrompue");
		menuGlobal(banque,compte);
	};break;
		}
case 3: {
	
	if(serviceclient.modifierProfile(compte, choix))menuModification(banque, compte);
	else {
		System.out.println("opperation interrompue");
		menuGlobal(banque,compte);
	};break;
}
case 4: {
	
	if(serviceclient.modifierProfile(compte, choix))menuModification(banque, compte);
	else {
		System.out.println("opperation interrompue");
		menuGlobal(banque,compte);
	};break;
}
case 5: {
	
	if(serviceclient.modifierProfile(compte, choix))menuModification(banque, compte);
	else {
		System.out.println("opperation interrompue");
		menuGlobal(banque,compte);
	};break;
}
case 6: {
	
	menuGlobal(banque,compte);
}
		default:
			throw new IllegalArgumentException("Unexpected value: " + choix);
		}
	}

	@Override
	public void menuRetrait(Banque banque, Compte compte) {
		System.out.println("====================================================");
		System.out.println("================> M E N U [RETRAIT] <===============");
		System.out.println("==                                                ==");
		System.out.println("= tapez 1 pour faire un retrait de 100DH           =");
		System.out.println("= tapez 2 pour faire un retrait de 200DH           =");
		System.out.println("= tapez 3 pour faire un retrait de 500DH           =");
		System.out.println("= tapez 4 pour faire un retrait de 1000DH          =");
		System.out.println("= tapez 5 pour faire un retrait de 2000DH          =");
		System.out.println("= tapez 6 pour faire un retrait d'un autre montant =");
		System.out.println("= tapez 7 pour revenir au menu principale          =");
		System.out.println("==                                                ==");
		System.out.println("====================================================");
		System.out.println("=> entrer votre choix:");
		int choix = clavier.nextInt();
		
		switch (choix) {
		case 1: {
			
			if(serviceclient.retrait(compte, (double) 100)) menuRetrait(banque, compte);
			else {
				System.out.println("operation interrompue");
				menuRetrait(banque, compte);
			}break;
		}
case 2: {
			
	if(serviceclient.retrait(compte, (double) 200))menuRetrait(banque, compte);
	else{
		System.out.println("operation iterrompue");
		menuRetrait(banque, compte);
	}break;
		}
case 3: {
	if(serviceclient.retrait(compte, (double) 500))menuRetrait(banque, compte);
	else {
		System.out.println("operation iterrompue");
		menuRetrait(banque, compte);
	}
	;break;
}
case 4: {
	
	if(serviceclient.retrait(compte, (double) 1000))menuRetrait(banque, compte);
	else {
		System.out.println("operation iterrompue");
		menuRetrait(banque, compte);
	}break;
}
case 5: {
	
	if(serviceclient.retrait(compte, (double) 2000))menuRetrait(banque, compte);
	else {
		System.out.println("operation iterrompue");
		menuRetrait(banque, compte);
	}break;
}
case 6: {
	System.out.println("==> entrer le montant que vous voulez retirer :");
	if(serviceclient.retrait(compte, clavier.nextDouble()))menuRetrait(banque, compte);
	else {
		System.out.println("operation iterrompue");
		menuRetrait(banque, compte);
	}break;
}
case 7: {
	
	menuGlobal(banque, compte);
}
		default:
			throw new IllegalArgumentException("Unexpected value: " + choix);
		}
	}

	@Override
	public void menuInformations(Banque banque,Compte compte) {
		
		System.out.println("============================================================");
		System.out.println("==================> M E N U [MODIFICATION] <================");
		System.out.println("==                                                        ==");
		System.out.println("= tapez 1 pour afficher votre profile                      =");
		System.out.println("= tapez 2 pour afficher le solde de votre compte           =");
		System.out.println("= tapez 3 pour afficher les derniers operations du compte  =");
		System.out.println("= tapez 4 pour afficher les operations d'aujourd'hui   !   =");
		System.out.println("= tapez 5 pour afficher l'archive des virments   !         =");
		System.out.println("= tapez 6 pour revenir au menu principale                  =");
		System.out.println("==                                                        ==");
		System.out.println("============================================================");
		System.out.println("=> entrer votre choix:");
		int choix= clavier.nextInt();
		
		switch (choix) {
		case 1: {
			
			System.out.println(compte.getPropriétaire().toString());
			menuInformations(banque, compte); break;
		}
case 2: {
			
			System.out.println(compte.getSolde());menuInformations(banque, compte);break;
		}
case 3: {
	
	serviceclient.afficherSolde(compte);menuInformations(banque, compte);break;
}
case 4: {
	
	serviceclient.afficherSolde(compte);menuInformations(banque, compte);break;
}
case 5: {
	
	serviceclient.afficherSolde(compte);menuInformations(banque, compte);break;
}
case 6: {
	
	menuGlobal(banque, compte);
}
		default:
			throw new IllegalArgumentException("Unexpected value: " + choix);
		}
	}

	@Override
	public void menuGlobal(Banque banque) {
		// TODO Auto-generated method stub
	}

}
