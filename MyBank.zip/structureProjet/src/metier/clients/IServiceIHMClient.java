package metier.clients;

import metier.authentification.IServiceIHM;
import presentation.modele.*;

public interface IServiceIHMClient extends IServiceIHM {

    void menuModification(Banque banque, Compte compte);
    void menuRetrait(Banque banque, Compte compte);
    void menuInformations(Banque banque,Compte compte);
    
}
