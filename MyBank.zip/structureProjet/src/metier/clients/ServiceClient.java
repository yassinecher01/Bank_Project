package metier.clients;

import dao.daoFiles.LogsDao;
import metier.InteractiveConsole;
import presentation.modele.*;

public  class  ServiceClient implements IServiceClient,InteractiveConsole{
	LogsDao dao = new LogsDao();

	@Override
	public boolean virement(Banque banque,Compte compte) {
		
		System.out.println("====================================================");
		System.out.println("================= virement d'argent ================");
		System.out.println("====================================================");
		System.out.println("=> entrer le numero de compte du beneficiaire  =====");
		System.out.println("====================================================");
		String compte2=clavier.nextLine();
		for (Client client : banque.getClientsDeBanque()) {
			for (Compte cmpt : client.getComptesClient()) {
				if(cmpt.getNumeroCompte().equals(compte2)) {
					System.out.println("=> entrer le montant du virement");
					int montant = clavier.nextInt();
					compte.setSolde(compte.getSolde()-montant);
					compte.setLog(TypeLog.RETRAIT, "retrait de votre compte d'un montant de "+montant);
					cmpt.setSolde(compte.getSolde()+montant);
					
					return true;
				}
				
			}
			
		}
		
		return false;
	}

	
	
	@Override
	public boolean versement(Compte compte) {
		System.out.println("====================================================");
		System.out.println("================ versement d'argent ================");
		System.out.println("====================================================");
		System.out.println("=> entrer le montant                               =");
		Double montant=clavier.nextDouble();
		compte.setSolde(compte.getSolde()+montant);
		compte.setLog(TypeLog.VERSEMENT, "versement a votre compte d'un montant de "+montant);
		System.out.println("versement a votre compte d'un montant de "+montant);
		return true;
	}

	@Override
	public boolean retrait(Compte compte, Double montant) {
		compte.setSolde(compte.getSolde()-montant);
		compte.setLog(TypeLog.RETRAIT, "retrait de votre compte d'un montant de "+montant);
		return true;
	}

	@Override
	public boolean modifierProfile(Compte compte,int choixModification) {
		switch (choixModification) {
		case 1: {
			
			String nom,prenom;
			System.out.println("entrer votre nouveau nom:");
			nom=clavier.nextLine();
			System.out.println("entrer votre nouveau prenom:");
			prenom=clavier.nextLine();
			compte.getPropriétaire().setNom(nom);
			compte.getPropriétaire().setNom(prenom);
			
		}
		case 2: {
			String mdp1,mdp2,mdp3;
			System.out.println("entrer votre mot de passe actuel:");
			mdp1=clavier.nextLine();
			if(compte.getPropriétaire().getMotDePasse().equals(mdp1)) {
				System.out.println("entrer votre nouveau mot de passe:");
				mdp2=clavier.nextLine();
				System.out.println("confirmer votre nouveau mot de passe:");
				mdp3=clavier.nextLine();
				if(mdp2.equals(mdp3)) {
					compte.getPropriétaire().setMotDePasse(mdp3);
				}
			}
		}
		case 3: {
			String email;
			System.out.println("entrer votre nouveau email:");
			email=clavier.nextLine();
			compte.getPropriétaire().setEmail(email);
		}
		case 4: {
			String cin;
			System.out.println("entrer votre nouveau n° cin:");
			cin=clavier.nextLine();
			compte.getPropriétaire().setCin(cin);
		}
		case 5: {
			String tel;
			System.out.println("entrer votre nouveau n° de telephone:");
			tel=clavier.nextLine();
			compte.getPropriétaire().setTel(tel);
		}
		
		default:
			throw new IllegalArgumentException("Unexpected value: " + choixModification);
		}
	}

	@Override
	public void dernièresOpérations(Compte compte) {
				for(Log log : compte.getLog()) {
					System.out.println(log);
				}
		
	}

	@Override
	public Double afficherSolde(Compte compte) {
				return compte.getSolde();
	}

	@Override
	public void afficherTicket() {
		// TODO Auto-generated method stub
		
	}

}
