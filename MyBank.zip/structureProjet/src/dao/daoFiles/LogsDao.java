package dao.daoFiles;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.stream.Collectors;

import dao.IDao;
import presentation.modele.Client;
import presentation.modele.Log;
import presentation.modele.Sexe;
import presentation.modele.TypeLog;

public class LogsDao implements IDao<Log, Integer> {

	@Override
	public List<Log> findAll() {
		List<Log> logs = new ArrayList<>();


        try {
           List<String> lines = Files.readAllLines(FileBasePaths.LOG_TABLE, StandardCharsets.UTF_8);
            lines.remove(0);

            if(!lines.isEmpty())
                       logs=
                       lines
                               .stream()
                               .map(line->{
                                   Log log = null;
                                   StringTokenizer st = new StringTokenizer(line, "\t\t\t");

                                   int     	 id              =   Integer.parseInt(st.nextToken());
                                   long   	 id_client       =   Long.parseLong(st.nextToken())   ;
                                   String    id_compte       =   st.nextToken()   ;
                                   String    date            =   st.nextToken();
                                   LocalDate dat;
                                   String    time            =   st.nextToken();
                                   LocalTime tim;
                                   String    type            =   st.nextToken();
                                   TypeLog  typ=null;
                                   String message = st.nextToken();
                                   
                                   DateTimeFormatter formatter =DateTimeFormatter.ofPattern("yyyy-mm-dd ");
                                   dat = LocalDate.parse(date,formatter) ;
                                   tim = LocalTime.parse(time,formatter) ;
                                   if(type.equals("VIREMENT")) typ=TypeLog.VIREMENT;
                                   if(type.equals("VERSEMENT")) typ=TypeLog.VERSEMENT;
                                   if(type.equals("RETRAIT")) typ=TypeLog.RETRAIT;
                                   if(type.equals("CREATION")) typ=TypeLog.CREATION;

                                   log = new Log(id_client,id_compte,dat, tim, typ, message);
                                    log.setId(id);
                                   return log;
                               })
                               .collect(Collectors.toList());


        } catch (IOException e) {
           e.printStackTrace();
        }

        return logs;
	}

	@Override
	public Log findById(Integer id) {
		return findAll().stream()
                .filter(log -> log.getId() == id)
                .findFirst()
                .orElse(null);
	}
	private int getIncrementedId() {
		var logList=findAll();
		int maxId=1;
		if(!logList.isEmpty()) {
			maxId= findAll().stream().map(log -> log.getId()).max((id1,id2)-> id1.compareTo(id2)).get();
		}
		return maxId;
	}

	@Override
	public Log save(Log t) {
		int id = getIncrementedId();
		String logStr = id +"\t\t\t"+
						t.getDate()+"\t\t\t"+
						t.getTime()+"\t\t\t"+
						t.getType()+"\t\t\t"+
						t.getMessage()+"\t\n";
		try {
            Files.writeString(FileBasePaths.LOG_TABLE, logStr, StandardOpenOption.APPEND);
            System.out.println("log n ° "+ id + " a été ajouté avec succès ^_^");
            t.setId(id);
            }
        catch (IOException e) { e.printStackTrace();}
		return t;
	}

	@Override
	public List<Log> saveAll(List<Log> liste) {
		return
                liste
                            .stream()
                            .map(log -> save(log))
                            .collect(Collectors.toList());
	}

	@Override
	public Log update(Log t) {
		List<Log> logsUpdated =
                findAll()
                        .stream()
                        .map(log -> {
                                        if(log.getId() == t.getId())
                                            return t;
                                        else
                                            return log;
                                        })
                                .collect(Collectors.toList());


try { Files.deleteIfExists(FileBasePaths.LOG_TABLE);} catch (IOException e) {e.printStackTrace();}
FileBasePaths.changeFile(FileBasePaths.LOG_TABLE, FileBasePaths.LOG_TABLE_HEADER);

saveAll(logsUpdated);

return t;
	}

	@Override
	public Boolean delete(Log t) {
		var logs = findAll();
        boolean deleted  =
                logs.remove(t);

        if(deleted) {
            /*
                        try {
                            Files.deleteIfExists(FileBasePaths.INDEX_CLIENT);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

             */
                        FileBasePaths.changeFile(FileBasePaths.LOG_TABLE, FileBasePaths.LOG_TABLE_HEADER);
                        saveAllWithIds(logs);
                     }

        return deleted;
	}
	public List<Log> saveAllWithIds(List<Log> listeLogs) {
        return
        		listeLogs
                        .stream()
                        .map(log -> saveWithID(log))
                        .collect(Collectors.toList());
    }
	public Log saveWithID(Log log) {

        String logStr =  log.getId() + "\t\t\t" +
        		log.getDate()+"\t\t\t"+
				log.getTime()+"\t\t\t"+
				log.getType()+"\t\t\t"+
				log.getMessage()+"\t\n";

        try {
            Files.writeString(FileBasePaths.LOG_TABLE, logStr, StandardOpenOption.APPEND);
            System.out.println("Client n ° "+ log.getId() + " a été ajouté avec succès ^_^");
        }
        catch (IOException e) { e.printStackTrace();}

        return log;
    }

	@Override
	public Boolean deleteById(Integer id) {
		var logs = findAll();
        boolean deleted  =
                logs.remove(findById(id));

        if(deleted) {
           /* try {
                Files.deleteIfExists(FileBasePaths.INDEX_CLIENT);
            } catch (IOException e) {
                e.printStackTrace();
            }

            */
           FileBasePaths.changeFile(FileBasePaths.LOG_TABLE, FileBasePaths.LOG_TABLE_HEADER);
            saveAllWithIds(logs);
        }

        return deleted;
	}

}
