package dao.daoFiles;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;
import java.util.stream.Collectors;

import dao.IDao;
import presentation.modele.Client;
import presentation.modele.Compte;
import presentation.modele.Sexe;

public class CompteDao implements IDao<Compte, String>  {
	ClientDao dao = new ClientDao();
	LocalDateTime   	date;

	@Override
	public List<Compte> findAll() {
		List<Compte> comptes = new ArrayList<>();


        try {
           List<String> lines = Files.readAllLines(FileBasePaths.ACCOUNT_TABLE, StandardCharsets.UTF_8);
            lines.remove(0);

            if(!lines.isEmpty())
                       comptes=
                       lines
                               .stream()
                               .map(line->{
                                   Compte cl = null;
                                   StringTokenizer st = new StringTokenizer(line, "\t\t\t");

                                   String     id              =   st.nextToken();
                                   st.nextToken();
//                                   DateTimeFormatter formatter =DateTimeFormatter.ofPattern("yyyy-mm-dd ");
//                                   date             =  LocalDateTime.parse(dat,formatter) ;
                                   Double   solde          =   Double.parseDouble(st.nextToken());
                                   long   	id_client           =   Long.parseLong(st.nextToken());

                                   
                                   Client c = dao.findById(id_client);
                                   cl = new Compte(solde,c);
                                    cl.setNumeroCompte(id);
                                   return cl;
                               })
                               .collect(Collectors.toList());


        } catch (IOException e) {
           e.printStackTrace();
        }

        return comptes;
	}

	@Override
	public Compte findById(String id) {
		return findAll().stream()
                .filter(compte -> compte.getNumeroCompte() == id)
                .findFirst()
                .orElse(null);
	}
	public List<Compte> findByClient(Long id){
		List<Compte> arr= findAll().stream()
                .filter(compte -> compte.getPropriétaire().getId().equals(id)).collect(Collectors.toList());
		return arr;
	}
	private String getIncrementedId(){

        var compteList = findAll();

        String maxId = "b-co001";

        if(!compteList.isEmpty())
            {
        	int a;
                maxId = findAll().stream().map(compte -> compte.getNumeroCompte()).max((id1,id2)-> id1.compareTo(id2)).get();
                ArrayList<Character> array = new ArrayList<>();
                for(int i=0;i<maxId.length();i++) {
                	array.add(maxId.charAt(i));
                }
                
                
                String st=null;
                for(char s : array) {
                	if(s>='0' && s<'9') {
                		a=Integer.parseInt(""+s);
                		a++;
                		array.set(array.indexOf(s), (char) a);
                	}
                	st+=s;
                }
                maxId=st;
            }

        return maxId;
    }

	@Override
	public Compte save(Compte t) {
		// Solution D'incrémentation 1
        String id = getIncrementedId();
        // Solution D'incrémentation 2
        //   id = getIncrementedIdByIndexFile(FileBasePaths.INDEX_CLIENT);
        String compteStr =  id + "\t\t\t" +
                        t.getDateCreation()+ "\t" +
                        t.getSolde()+ "\t\t" +
                        t.getPropriétaire().getId()+ "\t\t\n";

        try {
            Files.writeString(FileBasePaths.ACCOUNT_TABLE, compteStr, StandardOpenOption.APPEND);
            System.out.println("Compte n ° "+ id + " a été ajouté avec succès ^_^");
            t.setNumeroCompte(id);
            }
        catch (IOException e) { e.printStackTrace();}

        return t;
	}
	 public Compte saveWithID(Compte compte) {

	        String comptetStr =  compte.getNumeroCompte() + "\t\t\t" +
	                compte.getDateCreation()+ "\t" +
	                compte.getSolde()+ "\t\t" +
	                compte.getPropriétaire().getId()+ "\t\t"  ;

	        try {
	        	Files.writeString(FileBasePaths.ACCOUNT_TABLE, comptetStr, StandardOpenOption.APPEND);
	            System.out.println("Compte n ° "+ compte.getNumeroCompte() + " a été ajouté avec succès ^_^");
	            
	        }
	        catch (IOException e) { e.printStackTrace();}

	        return compte;
	    }

	@Override
	public List<Compte> saveAll(List<Compte> liste) {
		return
                liste
                            .stream()
                            .map(compte -> save(compte))
                            .collect(Collectors.toList());
	}
	public List<Compte> saveAllWithIds(List<Compte> listeComptes) {
        return
                listeComptes
                        .stream()
                        .map(compte -> saveWithID(compte))
                        .collect(Collectors.toList());
    }

	@Override
	public Compte update(Compte t) {
		List<Compte> compteUpdated =
                findAll()
                        .stream()
                        .map(compte -> {
                                        if(compte.getNumeroCompte().equals(t.getNumeroCompte()))
                                            return t;
                                        else
                                            return compte;
                                        })
                                .collect(Collectors.toList());
		try { Files.deleteIfExists(FileBasePaths.ACCOUNT_TABLE);} catch (IOException e) {e.printStackTrace();}
        FileBasePaths.changeFile(FileBasePaths.ACCOUNT_TABLE, FileBasePaths.ACCOUNT_TABLE_HEADER);

saveAll(compteUpdated);

return t;
	}

	@Override
	public Boolean delete(Compte t) {
		var comptes = findAll();
        boolean deleted  =
                comptes.remove(t);

        if(deleted) {
            /*
                        try {
                            Files.deleteIfExists(FileBasePaths.INDEX_CLIENT);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

             */
                        FileBasePaths.changeFile(FileBasePaths.ACCOUNT_TABLE, FileBasePaths.ACCOUNT_TABLE_HEADER);
                        saveAllWithIds(comptes);
                     }

        return deleted;
	}

	@Override
	public Boolean deleteById(String id) {
		var comptes = findAll();
        boolean deleted  =
                comptes.remove(findById(id));

        if(deleted) {
           /* try {
                Files.deleteIfExists(FileBasePaths.INDEX_CLIENT);
            } catch (IOException e) {
                e.printStackTrace();
            }

            */
           FileBasePaths.changeFile(FileBasePaths.ACCOUNT_TABLE, FileBasePaths.ACCOUNT_TABLE_HEADER);
            saveAllWithIds(comptes);
        }

        return deleted;
	}

}
