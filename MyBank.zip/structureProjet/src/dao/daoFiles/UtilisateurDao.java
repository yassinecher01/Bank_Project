package dao.daoFiles;

import java.util.List;

import dao.IUtilisateurDAO;
import presentation.modele.Utilisateur;

public class UtilisateurDao implements IUtilisateurDAO {
    @Override
    public List<Utilisateur> findAll() {
        return null;
    }

    @Override
    public Utilisateur findById(Long aLong) {
        return null;
    }

    @Override
    public Utilisateur save(Utilisateur utilisateur) {
        return null;
    }

    @Override
    public List<Utilisateur> saveAll(List<Utilisateur> liste) {
        return null;
    }

    @Override
    public Utilisateur update(Utilisateur utilisateur) {
        return null;
    }

    @Override
    public Boolean delete(Utilisateur utilisateur) {
        return null;
    }

    @Override
    public Boolean deleteById(Long aLong) {
        return null;
    }

    @Override
    public Utilisateur findByLoginAndPass(String login, String pass) {



        return null;
    }
}
