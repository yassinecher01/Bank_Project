package presentation.modele;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import dao.daoFiles.LogsDao;

public class Compte {
	LogsDao dao = new LogsDao();
    private static long          compteur = 1;
    private String          numeroCompte;
    private Double          solde;
    private LocalDateTime   dateCreation;
    private Client          propriétaire;
    private ArrayList<Log>       logs = (ArrayList<Log>) dao.findAll();

    public void setDateCreation() { this.dateCreation = LocalDateTime.now(); }
    public void setDateCreation(LocalDateTime date) { this.dateCreation = date ; }
    public void setPropriétaire(Client propriétaire) {
        this.propriétaire = propriétaire;
    }
    public void setSolde(Double solde) {
        this.solde = solde;
    }
    public void setLog(TypeLog type, String msg) {

        Log log = new Log(propriétaire.getId(),getNumeroCompte(), LocalDate.now(), LocalTime.now(), type, msg);
        logs.add(log);
        dao.save(log);
    }
    public ArrayList<Log> getLog(){
    	return logs;
    }

    public Client           getPropriétaire() {
        return propriétaire;
    }
    public Double           getSolde() {
        return solde;
    }
    public String getNumeroCompte() {
        return numeroCompte;
    }
    public void setNumeroCompte() {
        this.numeroCompte = "b-co00" + compteur++;
    }
    public void setNumeroCompte(String numeroCompte) {
        this.numeroCompte = numeroCompte;
    }
    public LocalDateTime    getDateCreation() {
        return dateCreation;
    }
    public List<Log>        getLogs() {
        return logs;
    }

    public Compte(){
        setNumeroCompte();
        setDateCreation();
        setSolde(0.0);
        setPropriétaire(null);
    }
    public Compte(Double solde, Client propriétaire){
        setNumeroCompte();
        setDateCreation();
        setSolde(solde);
        setPropriétaire(propriétaire);
    }
    public Compte(Double solde, Client propriétaire, LocalDateTime date){
        setNumeroCompte();
        setDateCreation(date);
        setSolde(solde);
        setPropriétaire(propriétaire);
    }
    
    
    @Override
    public boolean equals(Object obj) {
    	if(obj instanceof Compte) {
    		if(solde.equals(((Compte) obj).getSolde()) && propriétaire.equals(((Compte) obj).getPropriétaire()) ) {
    			return true;
    		}return false;
    		
    	}return false;
    }
    @Override
    public String toString() {

        String      compteStr  = "------------------------------------------------------\n";
                    compteStr += "| N° de Compte            : "   + getNumeroCompte()   + "\n";
                    compteStr += "| Solde du Compte         : "   + getSolde()    + " Dh\n" ;
                    compteStr += "| Propriétaire du Compte  : "   + getPropriétaire().getNomComplet() + "\n" ;
                    compteStr += "------------------------------------------------------\n";

        return compteStr;
    }



}
