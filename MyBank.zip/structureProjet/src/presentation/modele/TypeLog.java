package presentation.modele;

public enum TypeLog {
	VIREMENT, VERSEMENT, RETRAIT, CREATION;
}
