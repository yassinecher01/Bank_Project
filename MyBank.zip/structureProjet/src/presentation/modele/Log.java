 package presentation.modele;

import java.time.LocalDate;
import java.time.LocalTime;

public class Log {
	static 	int compteur = 1;
	private int id;
	private Long id_client;
	private String id_compte;
    private LocalDate date;
    private LocalTime time;
    private TypeLog type;
    private String message;
    
    
    public void         setId() {
        this.id = compteur++;
    }
    public void         setId(int id) {
        this.id = id;
    }
    public int 			getId() {
    	return id;
    }
    public LocalDate	getDate() {
    	return date;
    }
    public LocalTime	getTime() {
    	return time;
    }
    public TypeLog		getType() {
    	return type;
    }
    public String		getMessage() {
    	return message;
    }
    public Long 		getId_client() {
		return id_client;
	}
	public String 		getId_compte() {
		return id_compte;
	}
    
    public Log(LocalDate date, String msg){
    	setId();
        this.date = date;
        this.message = msg;
    }

    public Log(Long id_client,String id_compte, LocalDate date, LocalTime time, TypeLog type, String msg){
    	setId();
    	this.id_client=id_client;
    	this.id_compte=id_compte;
        this.date = date;
        this.message = msg;
        this.time = time;
        this.type = type;
    }

    @Override
    public String toString() {
        String logStr = "[" + date + "]["+time+"][{"+type+"}] : " +  message;

        return logStr;
    }
	
}
