package presentation.modele;

public interface AffichageInfos {

     void afficherBref();
     void afficherLesLogs();
     void afficherInformations();
     void afficherInformationsDétaillées();

}
